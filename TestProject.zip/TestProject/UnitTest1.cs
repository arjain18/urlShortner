using UrlShortner.Controllers;
namespace TestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestResponse()
        {
            HomeController obj = new HomeController(null);
            var result = obj.IndexApi("b");
            Assert.AreEqual("www.shorty.com/ALUUM", result);
        }
        [TestMethod]
        public void TestResponseSize()
        {
            HomeController obj = new HomeController(null);
            var result = obj.IndexApi("b");
            Assert.AreEqual("20", result.Length.ToString());
        }
    }
}